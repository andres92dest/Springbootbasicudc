/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appbd.appudc.servicio;


import com.appbd.appudc.entidad.Municipio;
import com.appbd.appudc.repository.MunicipioRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author andre
 */

@Service
public class MunicipioService {
    
    @Autowired
    private MunicipioRepository repository;
    
    public List<Municipio> getMunicipios(){
        return repository.findAll();
    }
    
    public Municipio saveMunicipio(Municipio municipio){
        return repository.save(municipio);
    }
    
}
