/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appbd.appudc.servicio;

import com.appbd.appudc.entidad.Departamento;
import com.appbd.appudc.repository.DepartamentoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author andre
 */

@Service

public class DepartamentoService {
    
    @Autowired
    private DepartamentoRepository repository;
    
    /**
     * Mostrar los registros de departamento
     */
 
    public List<Departamento> getDepartamentos(){
        return repository.findAll();
    }
    
    public Departamento saveDepartamento(Departamento departamento){
        return repository.save(departamento);
    }
    
}
